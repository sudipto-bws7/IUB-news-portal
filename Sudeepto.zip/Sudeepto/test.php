<?php
// test.php
echo "<h1>Hello World</h1>";
echo "<p>PHP is working!</p>";
echo "<p>Server: " . $_SERVER['SERVER_SOFTWARE'] . "</p>";
?>
